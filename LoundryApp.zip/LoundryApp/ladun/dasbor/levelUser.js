//masih dalam planning nih javascript
$(document).ready(function(){
  
});
