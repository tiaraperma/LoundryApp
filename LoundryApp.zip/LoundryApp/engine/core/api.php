<?php
 
 class api_const{
     private $server    = '';
     private $header    = '';
     private $key       = '';
 }