<?php

class LevelUser extends Route{

    public function index(){
        $this -> bind('dasbor/levelUser/levelUser');
    }

}
