<?php

class awsConnect extends Route{

    private $user_id;
    private $cluster_id;

   public function __construct()
   {
       $this -> st = new state;
   }

   public function index()
   {

   }

   public function checkPhoneNumberValidate()
   {
       $key         = '';
       $username    = '';
       $cache_id    = '';
          
   }

}