<?php

class Tester extends Route{
    
    public function index()
    {   
       
    }  
}
